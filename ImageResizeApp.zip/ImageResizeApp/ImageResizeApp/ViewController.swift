//
//  ViewController.swift
//  ImageResizeApp
//
//  Created by Hitesh Rasal on 20/09/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgHeight: NSLayoutConstraint!
    @IBOutlet weak var imgView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        downloadImgFrmUrl()
    }
    
    func downloadImgFrmUrl() {
        loadImgFrmUrl(urlString: "https://www.architecturalrecord.com/ext/resources/Issues/2016/May/1605-Architecture-Creativity-wHY-Louisville-Speed-Art-Museum-01.jpg") {[weak self] (image) in
            if image != nil {
                let ratio = image!.size.width / image!.size.height
                let newHeight = (self?.imgView.frame.width)! / ratio
                self?.imgHeight.constant = newHeight
                
                let targetSize = CGSize(width: (self?.imgView.frame.width)!, height: newHeight)

                if let scaledImage = image?.scalePreservingAspectRatio(
                    targetSize: targetSize) {
                    self?.imgView.image = scaledImage
                    self?.view.layoutIfNeeded()
               }
            }
        }
    }
    
}


