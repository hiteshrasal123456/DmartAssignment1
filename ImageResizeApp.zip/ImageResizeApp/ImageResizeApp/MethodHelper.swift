//
//  MethodHelper.swift
//  ImageResizeApp
//
//  Created by Hitesh Rasal on 22/09/21.
//

import UIKit

public func loadImgFrmUrl(urlString: String, completionHandler:@escaping (_ img:UIImage?) -> ()) {
    let cache =  URLCache.shared
    let url = URL(string: urlString)
    let request = URLRequest(url: url!)
    if let data = cache.cachedResponse(for: request)?.data, let image = UIImage(data: data) {
        completionHandler(image)
    } else {
        URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            DispatchQueue.main.async {
                if let data = data, let response = response, ((response as? HTTPURLResponse)?.statusCode ?? 500) < 300, let image = UIImage(data: data) {
                    
                    let cachedData = CachedURLResponse(response: response, data: data)
                    cache.storeCachedResponse(cachedData, for: request)
                    completionHandler(image)
                } else {
                    completionHandler(nil)
                }
            }
            
        }).resume()
    }
}


extension UIImage {
    func scalePreservingAspectRatio(targetSize: CGSize) -> UIImage {
        let widthRatio = targetSize.width / size.width
        let heightRatio = targetSize.height / size.height
        let scaleFactor = min(widthRatio, heightRatio)

        let scaledImageSize = CGSize(
            width: size.width * scaleFactor,
            height: size.height * scaleFactor
        )
        let renderer = UIGraphicsImageRenderer(size: scaledImageSize)

        let scaledImage = renderer.image { _ in
            self.draw(in: CGRect(
                origin: .zero,
                size: scaledImageSize
            ))
        }
      return scaledImage
    }
}
